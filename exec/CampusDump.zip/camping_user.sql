-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6c103.p.ssafy.io    Database: camping
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_uid` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `profile` varchar(200) DEFAULT NULL,
  `user_state` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('9EslcdhWfaRRyMs4utt5b6uOo1J2','서은민','https://lh3.googleusercontent.com/a-/AOh14GhanPxMRlZp5w9epttjWtQVta4p9Ju5yF0MxxciRQ=s96-c',0),('CzskWm8Hb8hXabcNXxOVzVvI9Pv1','박주한','https://lh3.googleusercontent.com/a-/AOh14GiufLB7NyXgm-XBWvQxn-cPi9uEMHCv8vHElHM8ug=s96-c',2),('d5rc4reFebRNBRbN3DieHOOAobi2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',0),('ef246DBqNAXdkapIfDPzeB98wi43','SUE CHOI','https://lh3.googleusercontent.com/a/AATXAJza9i3BLolbrPQLdlRGR4JWqsmXIGRIo7yfkLI8=s96-c',0),('ehcXulZvkXNgjQbq70OHcwLnjf92','박주한','https://lh3.googleusercontent.com/a-/AOh14GiufLB7NyXgm-XBWvQxn-cPi9uEMHCv8vHElHM8ug=s96-c',0),('eKp7bYABd7M0l8NCyHeGQNPL9Ww2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('FamVg6jCoUaL3tjg7Q9raF9DjjM2','Jemin Lee','https://lh3.googleusercontent.com/a/AATXAJyEHb5qY4-Q-QsdFrgFCR6AW59FHxubVeqwgsT4=s96-c',2),('hNbcLcerBRTL3Xf8xhMy88ZvKyl2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('HVdfguXGKHSP7qUKGFhlH9BoCnG2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('ICjSmRI6PCflhn03UcZQAhKXYK23','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('j5MJGxl40LhySBEVYyxSnT9TLbY2','Jemin Lee','https://lh3.googleusercontent.com/a/AATXAJx3v-CTyKB9pskxE8SaKxYVjLMBHT0UA9dAYWTu=s96-c',0),('KWbwUg0w2wTO3s84sHJpkV4sZYe2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('MK2COCjCXySa0jMxqNkeYbSlG8q1','QLab King','https://lh3.googleusercontent.com/a-/AOh14GjytNQpul2w_rqTipHIYBP91YaPgJyEvi-96YvS=s96-c',0),('moqOslPZocRYO91pZxG8LzlQdnH2','daw','https://c103-camping.s3.ap-northeast-2.amazonaws.com/383f88b9-1cd6-4407-95dd-548e7f8e046e123.png',2),('mwVGqsjeDSdFr62tFZyfuMexmPq2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('nSxLJnrNdaVy4glSSOqGymXMEzK2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('oE3VwawpjIe9KYKBcXBzpFrE5Ie2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('oeuG301zsMTgf0J3lbBRQmCHEJ62','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('OY50Qp6k3Oa1b46pYdsPvBywwsx1','최다운','https://lh3.googleusercontent.com/a/AATXAJwH_7LSjJ7HrZZkPw5dFkpxzDtfwlfbpbMuVnDV=s96-c',0),('R7mjH5qlkoW9AGGrlAcp7jTK1SW2','백지영','https://lh3.googleusercontent.com/a/AATXAJxz6Gpa19gZda3j1wc2sDL9uAwUm5PLxo9k9Y83=s96-c',0),('Sc63TiustiQeQrFW13oslaQnsYF2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',2),('T95kw47oV1e2PITBVLUdzZjpb7p2','Chaeryun Kim','https://lh3.googleusercontent.com/a/AATXAJzBnRafDMzm68L2JvyUdUAnnp4n2mDd1rxn8EU-=s96-c',0),('u6CU5ZoboQbPa4JJZ1nOkX2brA33','장다빈','https://lh3.googleusercontent.com/a/AATXAJwQce0LMwlf75u3Tar8jcnU5W5TuBTprfueoMwV=s96-c',0),('vdhM353swDPi0oVgsKe6nQpfzLg1','sohee','https://c103-camping.s3.ap-northeast-2.amazonaws.com/f9dd8c88-2591-4318-98b6-1897ca6e8d60KakaoTalk_20220317_153844739.png',0),('vidDywG4EPOxMxbZVlCdMOk7YyW2','김성현','https://lh3.googleusercontent.com/a/AATXAJw_5Pd90AKlQP7ZuXQFxJvnTtLybOquxOE6i8Ob=s96-c',0),('wIl4fpvjg4eDiOOuHUgDNA6EmeJ3','주한','https://c103-camping.s3.ap-northeast-2.amazonaws.com/c4d72c1f-1b0c-47d9-a3f8-cda2ca496c6bprofile.png',0),('XJWawCRExKYICIP3i7U6gBwoueW2','Joohan Park','https://lh3.googleusercontent.com/a-/AOh14GgojylNxLvF1lvkLdNlAfNp9HfSz3as7gLpRr83HQ=s96-c',0),('xy9orPOyEMT4suhlKZ7mBchozMG2','이윤우','https://lh3.googleusercontent.com/a-/AOh14GggTlASEMBQs1zt1pkGRvdEd7UB2dATdHcduU8f=s96-c',0),('ZvkyCnuADqQkP8rOLz0sgm7M1323','박주한','https://c103-camping.s3.ap-northeast-2.amazonaws.com/b8a387f2-2849-4d7f-b1a9-d75082e65bef%ED%8E%B8%EC%A7%912.jpg',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:52:52
