-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6c103.p.ssafy.io    Database: camping
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey` (
  `user_uid` varchar(45) NOT NULL,
  `q1_equipment` tinyint NOT NULL,
  `q2_distance` tinyint NOT NULL,
  `q3_environment` varchar(10) NOT NULL,
  `q4_pet` tinyint NOT NULL,
  `user_x` double NOT NULL,
  `user_y` double NOT NULL,
  PRIMARY KEY (`user_uid`),
  KEY `fk_survey2_user1_idx` (`user_uid`),
  CONSTRAINT `fk_survey2_user1` FOREIGN KEY (`user_uid`) REFERENCES `user` (`user_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES ('9EslcdhWfaRRyMs4utt5b6uOo1J2',1,1,'해변',1,126.9137408,35.1404032),('j5MJGxl40LhySBEVYyxSnT9TLbY2',1,2,'계곡',1,126.8088832,35.1698944),('KWbwUg0w2wTO3s84sHJpkV4sZYe2',0,2,'산',0,128.5898171,35.3822939),('MK2COCjCXySa0jMxqNkeYbSlG8q1',1,1,'해변',1,126.9137408,35.1404032),('moqOslPZocRYO91pZxG8LzlQdnH2',1,0,'산',1,127.4150912,36.3134976),('u6CU5ZoboQbPa4JJZ1nOkX2brA33',0,0,'산',0,126.81425,37.5704231),('wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',1,0,'계곡',0,127.179438,37.5666405);
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:53:01
