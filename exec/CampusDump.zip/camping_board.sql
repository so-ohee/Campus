-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6c103.p.ssafy.io    Database: camping
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(45) NOT NULL,
  `user_uid` varchar(45) NOT NULL,
  `camping_id` bigint DEFAULT NULL,
  `title` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT NULL,
  `delete_state` tinyint NOT NULL DEFAULT '0',
  `hit` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`board_id`),
  KEY `fk_review_user_idx` (`user_uid`),
  KEY `fk_review_camping21_idx` (`camping_id`),
  CONSTRAINT `fk_review_camping21` FOREIGN KEY (`camping_id`) REFERENCES `camping` (`camping_id`),
  CONSTRAINT `fk_review_user` FOREIGN KEY (`user_uid`) REFERENCES `user` (`user_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (29,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',944,'수정','수정','2022-03-28 11:05:58','2022-03-31 10:39:44',1,1),(30,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',944,'이 캠핑장 추천니다','난 여기 좋던데여!!!!!','2022-03-28 11:06:44',NULL,1,7),(31,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',77,'이 캠핑장 추천니다','난 여기 좋던데여!!!!!','2022-03-28 11:12:28',NULL,1,5),(32,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',2095,'이 캠핑장 추천니다','난 여기 좋던데여!!!!!','2022-03-28 11:13:19',NULL,1,15),(33,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',2095,'사장님 또 방문하겠습니다!!!','난 여기 좋던데여!!!!!','2022-03-28 11:36:00',NULL,1,8),(34,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',2095,'사장님 또 방문하겠습니다!!!','난 여기 좋던데여!!!!!','2022-03-29 11:34:38',NULL,1,52),(35,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',2095,'사장님 또 방문하겠습니다!!!','추천','2022-03-30 00:45:13',NULL,1,85),(49,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',3,'그럭저럭입니다','그럭저럭입니다','2022-03-30 15:30:54',NULL,1,264),(50,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',442,'무난','무난','2022-03-31 01:15:05',NULL,1,79),(51,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',7344,'작성했습니다','작성했습니다','2022-03-31 02:39:04',NULL,1,11),(52,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',7735,'수정 완료했습니다','수정 완료했습니다','2022-03-31 02:40:13','2022-03-31 04:47:53',1,51),(53,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',563,'캠핑장 리뷰 작성','캠핑장 리뷰 작성\n','2022-03-31 05:25:17',NULL,1,54),(54,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',563,'수정 완료','수정 완료','2022-03-31 05:39:28','2022-04-04 06:01:38',1,3334),(55,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',563,'수정완료입니다','수정완료입니다','2022-04-04 06:06:01','2022-04-04 06:07:15',1,10),(59,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',563,'캠핑장 다녀왔습니다','캠핑장 다녀왔습니다','2022-04-04 07:03:10',NULL,1,70),(60,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',508,'test','test','2022-04-04 07:03:54',NULL,1,42),(61,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',508,'test','test','2022-04-05 01:43:08',NULL,1,1),(64,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',7735,'1','1','2022-04-05 13:45:17',NULL,1,6),(65,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',100157,'3','3','2022-04-05 13:45:32',NULL,1,2),(66,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',100005,'3','3','2022-04-05 13:45:47',NULL,1,2),(67,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',7915,'4','4','2022-04-05 13:45:58',NULL,1,4),(69,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7520,'ㅇ','ㅇ','2022-04-05 15:59:14',NULL,1,1),(70,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7520,'11','11','2022-04-05 16:02:19',NULL,1,51),(71,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'test','test','2022-04-06 12:51:26',NULL,1,15),(72,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'테스트','테스트','2022-04-06 13:23:32',NULL,1,8),(73,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'1','1','2022-04-06 13:26:52',NULL,1,4),(74,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'2','2','2022-04-06 13:27:14',NULL,1,3),(75,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'3','3','2022-04-06 13:27:26',NULL,1,4),(76,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'4','4','2022-04-06 13:27:40',NULL,1,4),(77,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',2095,'5','5','2022-04-06 13:28:31',NULL,1,15),(78,'후기','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',7735,'집에서 가깝고 좋습니다!','집에서 가까워서 금방 갈 수 있었습니다. 시설도 괜찮고 사장님도 친철하셔서 강추합니다','2022-04-06 15:57:00',NULL,1,6),(79,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7799,'캠핑장 너무 좋아요! 바다가 잘 보여요!','!!','2022-04-06 15:57:35',NULL,0,6),(80,'자유','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',NULL,'강원도 캠핑장 추천해주세요!!','이번 휴가 강원도로 가려 하는데 강원도에 있는 캠핑장 추천 부탁드려요!!','2022-04-06 15:57:41',NULL,0,7),(81,'Q&A','j5MJGxl40LhySBEVYyxSnT9TLbY2',NULL,'캠핑초보입니다. 캠핑 장비 어떤게 좋나요?','!','2022-04-06 15:58:02','2022-04-07 08:24:24',0,14),(82,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',508,'지금 봄날씨에 가기 좋은 캠핑장입니다','!','2022-04-06 15:58:33',NULL,0,6),(83,'Q&A','wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',NULL,'어디서 캠핑용품 구매하시나요?','다들 어디서 캠핑용품 구매하시나요?? 사이트 알려주세여!!','2022-04-06 15:58:37',NULL,0,10),(84,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',333,'너무 좋아요~~~~~','~','2022-04-06 15:59:04',NULL,0,8),(85,'자유','j5MJGxl40LhySBEVYyxSnT9TLbY2',NULL,'같이 캠핑 가실 분 구해요!!','!','2022-04-06 15:59:38',NULL,0,12),(86,'후기','KWbwUg0w2wTO3s84sHJpkV4sZYe2',100157,'친구들과 가평에서 재미있게 놀았습니다 또 가고 싶어요!!!','가평으로 놀러가요!!!','2022-04-06 16:00:28','2022-04-07 18:27:41',1,25),(92,'자유','MK2COCjCXySa0jMxqNkeYbSlG8q1',NULL,'유튜브 보고 가입했어요!','안녕하세요~~','2022-04-06 16:53:00',NULL,0,27),(94,'후기','MK2COCjCXySa0jMxqNkeYbSlG8q1',7196,'사장님 너무 친절하고 좋으세요!','다음에 또 방문하겠습니당','2022-04-06 19:00:56','2022-04-06 11:28:18',0,16),(95,'후기','MK2COCjCXySa0jMxqNkeYbSlG8q1',3440,'이제 수정이 제대로 되겠죠','ㅇㅇ','2022-04-06 19:04:24','2022-04-06 11:21:38',0,36),(96,'후기','moqOslPZocRYO91pZxG8LzlQdnH2',7196,'강추해요!!!','뷰도 좋고, 시설이랑 사장님도 친절해요\n완전 좋습니당!','2022-04-06 20:30:47',NULL,1,13),(97,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7196,'바다가 정말 예쁜 캠핑장!','추천합니다!!!!','2022-04-07 09:33:23','2022-04-07 18:26:21',0,57),(98,'후기','vdhM353swDPi0oVgsKe6nQpfzLg1',7196,'바다 앞이라서 완전 좋았어요!','친구들과 잘 놀다 왔어요ㅎㅎ \n또 가고 싶다!','2022-04-07 11:03:35','2022-04-07 17:55:26',0,276),(99,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7111,'test','test','2022-04-07 12:12:48',NULL,1,4),(100,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',100002,'test','test','2022-04-07 12:13:16',NULL,1,2),(101,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7191,'test','test','2022-04-07 12:15:05',NULL,1,2),(102,'후기','MK2COCjCXySa0jMxqNkeYbSlG8q1',2167,'여수 밤바다~','호호','2022-04-07 14:25:34',NULL,1,3),(103,'후기','9EslcdhWfaRRyMs4utt5b6uOo1J2',7196,'운동시설이 크고 좋네요','다음에 또 방문하고 싶어요!','2022-04-07 14:35:14','2022-04-07 05:37:30',1,14),(104,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7480,'12','12','2022-04-07 14:39:18','2022-04-07 05:40:04',1,70),(105,'후기','MK2COCjCXySa0jMxqNkeYbSlG8q1',7196,'확장자',',ㅣㅣㅣ','2022-04-07 15:17:01',NULL,1,4),(106,'후기','9EslcdhWfaRRyMs4utt5b6uOo1J2',7196,'이건?','이건?','2022-04-07 15:18:22',NULL,1,2),(107,'후기','9EslcdhWfaRRyMs4utt5b6uOo1J2',7196,'운동시설이 크고 좋네요!','다음에 또 방문하고 싶어요 ㅎㅎ','2022-04-07 15:24:32',NULL,1,1),(108,'후기','9EslcdhWfaRRyMs4utt5b6uOo1J2',7196,'운동시설이 크고 좋아요!','다음에 또 방문하고 싶습니당ㅎㅎ!!!!!!!!!~!','2022-04-07 15:26:32','2022-04-07 17:52:54',0,66),(109,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',6944,'test12','test','2022-04-07 17:25:17','2022-04-07 08:28:36',1,17),(110,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7520,'1234','1234','2022-04-07 17:32:26','2022-04-07 08:32:49',1,4),(117,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7520,'123','123','2022-04-07 18:07:30',NULL,1,1),(120,'후기','j5MJGxl40LhySBEVYyxSnT9TLbY2',7520,'12','12','2022-04-07 18:21:02',NULL,1,1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:52:58
