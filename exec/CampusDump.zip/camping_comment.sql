-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6c103.p.ssafy.io    Database: camping
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `user_uid` varchar(45) NOT NULL,
  `board_id` int NOT NULL,
  `comment` varchar(400) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `fk_comment_review_review1_idx` (`board_id`),
  KEY `fk_comment_user1_idx` (`user_uid`),
  CONSTRAINT `fk_comment_review_review1` FOREIGN KEY (`board_id`) REFERENCES `board` (`board_id`),
  CONSTRAINT `fk_comment_user1` FOREIGN KEY (`user_uid`) REFERENCES `user` (`user_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (87,'wIl4fpvjg4eDiOOuHUgDNA6EmeJ3',83,'사이트 알려주세요!','2022-04-06 16:17:35',NULL),(91,'vdhM353swDPi0oVgsKe6nQpfzLg1',97,'저도 가봤는데 좋더라구요!','2022-04-07 11:07:24',NULL),(96,'KWbwUg0w2wTO3s84sHJpkV4sZYe2',98,'저도 가고 싶어요!ㄴㅇㅁ!!!','2022-04-07 13:34:59','2022-04-07 06:02:35'),(98,'KWbwUg0w2wTO3s84sHJpkV4sZYe2',92,'수정','2022-04-07 13:36:52','2022-04-07 04:43:27'),(111,'MK2COCjCXySa0jMxqNkeYbSlG8q1',98,'오!','2022-04-07 14:23:29',NULL),(147,'j5MJGxl40LhySBEVYyxSnT9TLbY2',98,'바다 가고 싶어요!','2022-04-07 17:54:05',NULL),(150,'j5MJGxl40LhySBEVYyxSnT9TLbY2',82,'12344','2022-04-07 18:47:40','2022-04-07 18:47:47'),(151,'9EslcdhWfaRRyMs4utt5b6uOo1J2',92,'제 채널 보신듯','2022-04-07 19:37:25',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 10:52:51
